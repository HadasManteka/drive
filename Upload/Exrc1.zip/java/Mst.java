public class Mst {
    Integer[] parents;
    int[] weights;

    public Mst(Integer[] parents, int[] weights) {
        this.parents = parents;
        this.weights = weights;
    }
}
