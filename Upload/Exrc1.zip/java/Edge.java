public class Edge {
    private int srcVertex;
    private int destVertex;
    private int weight;

    public Edge(int srcVertex, int destVertex, int weight) {
        this.srcVertex = srcVertex;
        this.destVertex = destVertex;
        this.weight = weight;
    }

    public int getSrcVertex() {
        return srcVertex;
    }

    public int getDestVertex() {
        return destVertex;
    }

    public int getWeight() {
        return weight;
    }
}
