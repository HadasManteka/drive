public class OutputPrinter {
    public static void printGraph(Graph g, String message) {
        System.out.println("----------------------------");
        System.out.println(message);
        int index = 0;
        for(; index < g.adjList.length; index++) {
            System.out.print("Adj of vertex[" + index + "]");

            for (Node node : g.adjList[index]) {
                System.out.print(" -> ");
                System.out.print("[" + node.getIndex() + " | W:" + node.getWeight() + "]");
            }
            System.out.println("");
        }
    }

    public static void printMST(Mst mst){
        System.out.println("----------------------------");
        System.out.println("MST - by Prim:");
        for(int i = 0; i < mst.parents.length; i++){
            System.out.print("Parent: " + mst.parents[i]);
            System.out.print(" Child: " + i);

            if(mst.parents[i] != null) {
                System.out.print(" Weight: " + mst.weights[i]);
            }
            System.out.println("");
        }
    }
}
