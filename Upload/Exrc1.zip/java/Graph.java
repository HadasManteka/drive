import java.util.LinkedList;

public class Graph {

    public LinkedList<Node>[] adjList;
}
