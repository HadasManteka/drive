// הדס מנטקה 211364542
// איתי קנורוביץ 322436601

public class Main {
    static final int VERTEXES_NUM = 20;
    static final int EDGES_NUM = 50;
    static final int MAX_WEIGHT = 70;
    static final int MIN_WEIGHT = 1;

    public static void main(String[] args) {

        Graph g = new Graph();
        GraphUtils.initGraph(g, VERTEXES_NUM, EDGES_NUM);
        OutputPrinter.printGraph(g, "My Graph after init:");

        Algorithm algorithm = new Algorithm();
        Mst mst = algorithm.primMst(g);
        OutputPrinter.printMST(mst);

        Graph newMST = GraphUtils.convertMstToList(mst);

        Edge newEdge = GraphUtils.addNewEdge(g, VERTEXES_NUM, MAX_WEIGHT);
        addNewEdgeAndPrint(algorithm, newEdge, newMST);

        newEdge = GraphUtils.addNewEdge(g, VERTEXES_NUM, MIN_WEIGHT);
        addNewEdgeAndPrint(algorithm, newEdge, newMST);
    }

    private static void addNewEdgeAndPrint(Algorithm algorithm, Edge newEdge, Graph mst) {
        algorithm.updateMst(mst, newEdge.getSrcVertex(), newEdge.getDestVertex(), newEdge.getWeight());
        OutputPrinter.printGraph(mst, "Updated MST after adding new edge: ");
    }
}
