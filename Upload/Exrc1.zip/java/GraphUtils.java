import java.util.LinkedList;

public class GraphUtils {
    public static void initGraph(Graph g, int vertexesNum, int edgesNum) {
        g.adjList = new LinkedList[vertexesNum];
        int edgesCount = 0;
        int srcVertex, destVertex;

        while (edgesCount < edgesNum) {
            srcVertex = (int) (Math.random() * vertexesNum);
            destVertex = (int) (Math.random() * vertexesNum);

            if (addEdge(g, srcVertex, destVertex, (int) (Math.random() * 28) + 2)) {
                edgesCount++;
            }
        }
    }

    public static boolean addEdge(Graph graph, int src, int dest, int weight) {
        if(src != dest && (graph.adjList[src] == null ||
                graph.adjList[src].stream().filter(n -> n.getIndex() == dest).findAny().orElse(null) == null)) {

            Node node0 = new Node(dest, weight);
            Node node = new Node(src, weight);
            if(graph.adjList[src] == null){
                graph.adjList[src] = new LinkedList<>();
            }
            if(graph.adjList[dest] == null){
                graph.adjList[dest] = new LinkedList<>();
            }
            graph.adjList[src].addLast(node0);
            graph.adjList[dest].addLast(node);

            return true;
        }

        return false;
    }

    public static Edge addNewEdge(Graph g, int vertexesNum, int weight) {
        int newSrcVertex = (int) (Math.random() * vertexesNum);
        int newDestVertex = (int) (Math.random() * vertexesNum);

        while (!GraphUtils.addEdge(g, newSrcVertex, newDestVertex, weight)) {
            newSrcVertex = (int) (Math.random() * vertexesNum);
            newDestVertex = (int) (Math.random() * vertexesNum);
        }

        System.out.println("New edge Added: " + newSrcVertex + "->" + newDestVertex + " | W: " + weight);
        return new Edge(newSrcVertex, newDestVertex, weight);
    }

    public static Graph convertMstToList(Mst mst) {
        Graph mstAsList = new Graph();
        mstAsList.adjList = new LinkedList[mst.parents.length];

        for(int i=0; i<mst.parents.length; i++) {
            mstAsList.adjList[i] = new LinkedList<>();
        }

        for(int i=0; i<mst.parents.length; i++) {
            if (mst.parents[i] != null) {
                mstAsList.adjList[mst.parents[i]].add(new Node(i, mst.weights[i]));
                mstAsList.adjList[i].add(new Node(mst.parents[i], mst.weights[i]));
            }
        }

        return mstAsList;
    }
}
