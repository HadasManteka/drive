public class Qnode {
    private final int INFINITE = 999999;
    private int key = INFINITE;
    private int index;

    public int getIndex() {
        return index;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
