#define _CRT_SECURE_NO_WARNINGS
#include <iostream>	
#include <string>
#include <fstream>
using namespace std;


// Const variables
const int MAT_ROW_SIZE = 8;
const int MAT_COL_SIZE = 8;
const int VEC_SIZE	   = 8;
const int WALL         = -1;
const int WALL_SIZE    = 1;
 
// Global variables
int g_BlackCells;
int g_WhiteCells;

// Enum declaration
enum Color
{
	WHITE,
	BLACK,
	EMPTY,
};

// Struct declaration
struct Cell
{
	int nRow;
	int nCol;
	Color clrColor;

};

//-----------------------------------------------------------------------------
//								Print Matrix Func
//								----------------
//
// General : Prints matrix.
//
// Parameters :
// arrnMatrix - the matrix to print (In).
// 
//
// Return Value : None.
//
//-----------------------------------------------------------------------------
void PrintMatrix(int iarrnMatrix[][MAT_COL_SIZE + 2 * WALL_SIZE])
{
	// Variables definition
	int nRowIndex;
	int nColIndex;

	// Code section

	// Initalize cells amount
	g_BlackCells = 0;
	g_WhiteCells = 0;

	// Starting from 1 because of the security wall
	for (nRowIndex = 1; nRowIndex <= MAT_ROW_SIZE; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_COL_SIZE; nColIndex++)
		{

			// If there is a white cell so we need to increase the 
			// White cells amount
			if (iarrnMatrix[nRowIndex][nColIndex] == WHITE)
			{
				cout << " |W";
				g_WhiteCells++;
			}
			// If there is a black cell so we need to increase the 
			// White cells amount
			else if (iarrnMatrix[nRowIndex][nColIndex] == BLACK)
			{
				cout << " |B";
				g_BlackCells++;
			}
			else
			{
				// Printing empty cell
				cout << " | ";
			}
		}

		cout << endl;
	}
}

//-----------------------------------------------------------------------------
//								Is Full Mat Func
//								----------------
//
// General : Checks if all the matrix's cells are full.
//
// Parameters :
// arrnMatrix - the matrix to check (In).
// 
//
// Return Value : 1 - if the matrix is full,
//				  0 - if not.
//
//-----------------------------------------------------------------------------
bool IsFullMat(int iarrnMatrix[][MAT_COL_SIZE + 2 * WALL_SIZE])
{
	// Variables definition	
	int nIndex;
	int nSecondIndex;

	// Code section

	// Checking the matrix cells
	for (nIndex = 1; nIndex <= MAT_ROW_SIZE; nIndex++)
	{
		for (nSecondIndex = 1; nSecondIndex <= MAT_COL_SIZE; nSecondIndex++)
		{

			// if there is one empty cell so the matrix is not full
			if (iarrnMatrix[nIndex][nSecondIndex] == EMPTY);
			{
				return (false);
			}
		}
	}

	// Means that the matrix is full so the return value is 1
	return (true);
}

//------------------------------------------------------------------------------
//								 IsBridge Func
//								----------------
//
// General : Checks if a bridge have been created.
//			 If a bridge have been created it colors him.
//
// Parameters :
// ioarrnMatrix - a reference to the matrix to check (In/Out).
// inChosenRow  - the row of the new cell (In).
// inChosenCol  - the col of the new cell (In).
// iclrColor    - the color of the new cell (In).
//
// Return Value : True  - if a bridge had created,
//				  False - if not.
//
//-----------------------------------------------------------------------------
bool IsBridge(int(&ioarrnMatrix)[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE], int inChosenRow, int inChosenCol, Color iclrColor)
{
	// Struct declaration
	struct Point
	{
		int nX;
		int nY;
	};

	// Arrays definition
	Point arrnVecArr[VEC_SIZE];
	Point arrnPointsArray;

	// Variables definition
	int   nIndex;
	int   nSecondIndexX   = 0;
	int   nSecondIndexY	  = 0;
	int nDiffColorCounter = 0;
	bool  IsOpposite	  = true;

	// Code section

	// Vectors array initialize
	arrnVecArr[0] = { 1,0 };
	arrnVecArr[1] = { -1,0 };
	arrnVecArr[2] = { 0,1 };
	arrnVecArr[3] = { 0,-1 };
	arrnVecArr[4] = { 1,1 };
	arrnVecArr[5] = { -1,-1 };
	arrnVecArr[6] = { 1,-1 };
	arrnVecArr[7] = { -1,1 };

	// Scanning the matrix by the vectors array
	for (nIndex = 0; nIndex < VEC_SIZE; nIndex++)
	{

		//  Checking the cells in the new direction of the vectors array
		//  And it will be true only if the the cell in the new direction is different 
		//  Of the color of the new cell that inserted.
		if (ioarrnMatrix[inChosenRow + arrnVecArr[nIndex].nY][inChosenCol + arrnVecArr[nIndex].nX] != EMPTY
			&& ioarrnMatrix[inChosenRow + arrnVecArr[nIndex].nY][inChosenCol + arrnVecArr[nIndex].nX] != iclrColor
			&& ioarrnMatrix[inChosenRow + arrnVecArr[nIndex].nY][inChosenCol + arrnVecArr[nIndex].nX] != WALL)
		{
			for (nSecondIndexX = arrnVecArr[nIndex].nX, nSecondIndexY = arrnVecArr[nIndex].nY;
				ioarrnMatrix[inChosenRow + nSecondIndexY][inChosenCol + nSecondIndexX] != WALL
				&& IsOpposite;
				nSecondIndexX += arrnVecArr[nIndex].nX, nSecondIndexY += arrnVecArr[nIndex].nY)
			{

				// If the cell is not empty and also not at the same color of the new cell so this is an opening of a bridge
				// It cant be a wall also because of the loop conditions
				if (ioarrnMatrix[inChosenRow + nSecondIndexY][inChosenCol + nSecondIndexX] != EMPTY
					&& ioarrnMatrix[inChosenRow + nSecondIndexY][inChosenCol + nSecondIndexX] != iclrColor)
				{

					// IsOpposite = means that the color of this cell is the opposite of the new cell
					IsOpposite = true;

					// counter that check how many different color are exist for coloring them
					nDiffColorCounter++;
				}
				else if (ioarrnMatrix[inChosenRow + nSecondIndexY][inChosenCol + nSecondIndexX] == EMPTY)
				{
					nDiffColorCounter = 0;

					break;
				}
				else
				{
					//Means that is a diffrent color that closes the bridge 
					IsOpposite = false;
				}
			}

			// if IsOpposite is false that means that there is a bridge
			if (!IsOpposite)
			{

				// Variables definiton
				int nColorIndexRow;
				int nLoopCounter = 0;
				int nSecondLoopCounter = 0;
				int nColorIndexCol;
				for (nColorIndexRow = inChosenRow + arrnVecArr[nIndex].nY;
					nLoopCounter <= nDiffColorCounter; /*Bridge closer*/
					nColorIndexRow += arrnVecArr[nIndex].nY)
				{
					nSecondLoopCounter = 0;

					// For coloring the exact amount of cells
					nLoopCounter++;
					for (nColorIndexCol = inChosenCol + arrnVecArr[nIndex].nX;
						nSecondLoopCounter <= nDiffColorCounter;/*Bridge closer*/
						nColorIndexCol += arrnVecArr[nIndex].nX)
					{

						// For coloring the exact amount of cells
						nSecondLoopCounter++;
						ioarrnMatrix[nColorIndexRow][nColorIndexCol] = iclrColor;
					}
				}

					return true;
				// Means that there is a bridge
			}
		}
	}

	// Means that a bridge have not created
	return false;
}

//-----------------------------------------------------------------------------
//								  File Open Func
//								 ----------------
//
// General : Open saved game that saved in to a file and insert the values
//			 Into the matrix.
//
// Parameters :
// oarrnMatrix - the matrix to fill with the file content (Out).
// 
//
// Return Value : None.
// 
//-----------------------------------------------------------------------------
void FileOpen(int(&oarrnMatrix)[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE])
{

	// File pointer variabes definition
	fstream fsFilePointer;

	// Variables definition
	char szFileName[20];
	int  nIndex = 0;
	int  nRow;
	int  nCol;
	int  nColor;
	int  nRowIndex;
	int  nColIndex;
	Cell cellBuffer;

	// Code section

	cout << "enter file name please with the ending '.bat' " << endl;
	cin >> szFileName;

	// Adding the ending of a file name
	strcat(szFileName, ".bat");

	// Opening binary file for reading
	fsFilePointer.open(szFileName, ios::binary | ios::in);

	// If the file didnt open so the program will ask for the name
	// Untill it open.
	while (!fsFilePointer.is_open())
	{

		// If the file isnt exist so we need to ask for the file name 
		// untill it will open
		cout << "The file doesnt exist , please enter name again" << endl;
		cin >> szFileName;
		fsFilePointer.open(szFileName, ios::binary | ios::in);
	}

	// Reading the amount of each cells
	fsFilePointer >> g_WhiteCells;
	fsFilePointer >> g_BlackCells;

	// Insert default values
	for (nRowIndex = 1; nRowIndex <= MAT_ROW_SIZE; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_COL_SIZE; nColIndex++)
		{
			oarrnMatrix[nRowIndex][nColIndex] = EMPTY;
		}
	}

	// Reading the structs from the file
	// And insert them into the array
	while (!fsFilePointer.eof())
	{

		fsFilePointer >> nRow;
		fsFilePointer >> nCol;
		fsFilePointer >> nColor;

		// Checking what is the color of the cell
		if (nColor == 0)
		{
			oarrnMatrix[nRow][nCol] = WHITE;
		}
		else
		{
			oarrnMatrix[nRow][nCol] = BLACK;
		}
	}

	// Closing file
	fsFilePointer.close();
}

//-----------------------------------------------------------------------------
//								  Save File Func
//								 ----------------
//
// General : Save the game into a file.
//
//
// Parameters :
// iarrnMatrix - the matrix to save (In).
// 
//
// Return Value : None.
// 
//
//-----------------------------------------------------------------------------
void SaveFile(int iarrnMatrix[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE])
{

	// File pointer declartaion
	fstream fsFilePointer;

	// Arrays definition
	Cell* cellArray = new Cell[g_BlackCells + g_WhiteCells];

	// Variables definition
	int  nArrayIndex = 0;
	int  nRowIndex;
	int  nColIndex;
	int nLoopIndex;
	Cell cellBuffer;
	char szFileName[20];

	// Code section

	cout << " Enter file name with the ending please " << endl;
	cin >> szFileName;

	// File ending
	strcat(szFileName, ".bat");

	// Open the file for writing
	fsFilePointer.open(szFileName, ios::binary | ios::out);

	// Checking if the file opened, if not so it is exiting from the function.
	if (!fsFilePointer.is_open())
	{
		cout << " Cant open file";
		return;
	}

	// Writing the amount of the black cells and the white cells
	fsFilePointer << g_WhiteCells << endl
		<< g_BlackCells << endl;

	// Writing the white and the black cells's amount
	for (nRowIndex = 1;
		nRowIndex <= MAT_ROW_SIZE;
		nRowIndex++)
	{
		for (nColIndex = 1;
			nColIndex <= MAT_COL_SIZE;
			nColIndex++)
		{

			// Only the cells that are not empty should be saved in the file
			if (iarrnMatrix[nRowIndex][nColIndex] != EMPTY)
			{
				cellArray[nArrayIndex].nRow = nRowIndex;
				cellArray[nArrayIndex].nCol = nColIndex;

				// Adjust the color of the cell
				switch (iarrnMatrix[nRowIndex][nColIndex])
				{

					// White color
					case (0):
					{
						cellArray[nArrayIndex].clrColor = WHITE;

						break;
					}
	
					// Black color
					default:
					{
						cellArray[nArrayIndex].clrColor = BLACK;

						break;
					}
				}

				// Increase the array index for the next cell
				nArrayIndex++;
			}
		}
	}

	// Writing all the cells information to the file
	for (nLoopIndex = 0; nLoopIndex < g_BlackCells + g_WhiteCells; nLoopIndex++)
	{
		cellBuffer = cellArray[nLoopIndex];
		fsFilePointer << cellArray[nLoopIndex].nRow << endl
			<< cellArray[nLoopIndex].nCol << endl
			<< cellArray[nLoopIndex].clrColor << endl;
	}

	// Closing  the file
	fsFilePointer.close();
}

//-----------------------------------------------------------------------------
//								  Reversi Game
//								-----------------
//
// General : This program simulate the game 'Reversi'.
//			 This program built for 2 players.
//
//
// Input : Players decisions about where to place their cells.
//
// Process : Placing the cells that the players chose, by creating
//			 certian combination something that calls a bridge is creating.
//			 The game ends when the board is full or when the players decide to
//			 save it. The winner is the one that has more cells.
//
// Output :  The winner of the game.
//
//-----------------------------------------------------------------------------
// Programmer : Itay Knurovich
// Student No : 8699636
// Date : 15.05.2019
//-----------------------------------------------------------------------------
void main()
{

	// Variable definition
	int MenuChoose;
	int arrnGameBoard[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE];
	int nRowIndex;
	int nColIndex;

	// Code section

	// The menu
	cout << " Wellcome to the Reversi Game ! " << endl
		<< " Press your chose please : " << endl << endl
		<< " 1 - New Game " << endl
		<< " 2 - Load Exist Game " << endl
		<< " 3 - Exit " << endl;
	cin >> MenuChoose;

	// Security wall
	for (nRowIndex = 0; nRowIndex < MAT_ROW_SIZE + 2 * WALL_SIZE; nRowIndex++)
	{
		for (nColIndex = 0; nColIndex < MAT_COL_SIZE + 2 * WALL_SIZE; nColIndex++)
		{
			arrnGameBoard[nRowIndex][nColIndex] = WALL;
		}
	}

	// Initialize matrix with empty cell
	for (nRowIndex = 1; nRowIndex <= MAT_ROW_SIZE; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_COL_SIZE; nColIndex++)
		{
			arrnGameBoard[nRowIndex][nColIndex] = EMPTY;
		}
	}

	switch (MenuChoose)
	{
		case (1):
		{
	
			//Declare on the game board as a matrix
			int nRow = 0;
			int nCol;
			int nRowIndex;
			int nColIndex;
			int nChoose;

			// New game start 
			arrnGameBoard[4][4] = WHITE;
			arrnGameBoard[5][5] = WHITE;
			arrnGameBoard[4][5] = BLACK;
			arrnGameBoard[5][4] = BLACK;
			PrintMatrix(arrnGameBoard);
				
			// The game is on untill the matrix is not full
			while (!IsFullMat(arrnGameBoard))	
			{
				cout << " Black cell ! " << endl
					<< " enter where you want to place your cell" << endl
					<< " First enter your row and then enter your col(1-8)" << endl;
				cin >> nRow >> nCol;
	
				// Check if he wants to end the game
				if (nRow == -999)
				{
					cout << "Do you want to save the game ? " << endl
						<< " press 1 to save or press any other key to exit" << endl;
					cin >> nChoose;
					if (nChoose == 1)
					{
						SaveFile(arrnGameBoard);
					}
	
				// Stopping the game
					break;
				}
	
				// Check if the cell is taken
				while (arrnGameBoard[nRow][nCol] != EMPTY)
				{
					cout << " The cell is already in taken " << endl;	
					cin >> nRow >> nCol;
				}
	
				arrnGameBoard[nRow][nCol] = BLACK;
				cout << arrnGameBoard[nRow][nCol] << endl;

				//Check if a bridge have been created
				if (IsBridge(arrnGameBoard, nRow, nCol, BLACK))
				{
					cout << " !!! Bridge !!!" << endl;
				}

				PrintMatrix(arrnGameBoard);

				// White cell turn
				cout << " White cell !" << endl
					<< " enter where you want to place your cell" << endl
					<< " First enter your row and then enter your col(1-8)" << endl;
				cin >> nRow >> nCol;
	
				// if nRow = -999 that means that the player wants to end the game
				if (nRow == -999)
				{
					cout << "Do you want to save the game ? " << endl
				   		 << " press 1 to save or press any other key to exit" << endl;
					cin >> nChoose;

				// If nChoose =1 that means that the player wants to save the game
				if (nChoose == 1)
				{
					SaveFile(arrnGameBoard);
				}

				//Stopping the game
				break;
			}

			// Check if the cell is taken
			while (arrnGameBoard[nRow][nCol] != EMPTY)
			{
				cout << " The cell is already in taken " << endl;
				cin >> nRow >> nCol;
			}

			arrnGameBoard[nRow][nCol] = WHITE;
			cout << arrnGameBoard[nRow][nCol] << endl;
			g_WhiteCells++;

			//Check if a bridge have been created
			if (IsBridge(arrnGameBoard, nRow, nCol, WHITE))
			{
				cout << " !!! Bridge !!!" << endl;
			}

			PrintMatrix(arrnGameBoard);
		}
				
			break;
		}
	case (2):
	{
		FileOpen(arrnGameBoard);
		int nRow;
		int nChoose;
		int nCol;

		while (!IsFullMat(arrnGameBoard))
		{
			cout << " Black cell ! " << endl
				<< " enter where you want to place your cell" << endl
				<< " First enter your row and then enter your col(1-8)" << endl;
			cin >> nRow >> nCol;

			// Check if he wants to end the game
			if (nRow == -999)
			{
				cout << "Do you want to save the game ? " << endl
					<< " press 1 to save or press any other key to exit" << endl;
				cin >> nChoose;
				if (nChoose == 1)
				{
					SaveFile(arrnGameBoard);
				}

				// Stopping the game
				break;
			}

			// Check if the cell is taken
			while (arrnGameBoard[nRow][nCol] != EMPTY)
			{
				cout << " The cell is already in taken " << endl;
				cin >> nRow >> nCol;
			}

			arrnGameBoard[nRow][nCol] = BLACK;
			cout << arrnGameBoard[nRow][nCol] << endl;

			//Check if a bridge have been created
			if (IsBridge(arrnGameBoard, nRow, nCol, BLACK))
			{
				cout << " !!! Bridge !!!" << endl;
			}

			PrintMatrix(arrnGameBoard);

			// White cell turn
			cout << " White cell !" << endl
				<< " enter where you want to place your cell" << endl
				<< " First enter your row and then enter your col(1-8)" << endl;
			cin >> nRow >> nCol;

			// if nRow = -999 that means that the player wants to end the game
			if (nRow == -999)
			{
				cout << "Do you want to save the game ? " << endl
					<< " press 1 to save or press any other key to exit" << endl;
				cin >> nChoose;

				// If nChoose =1 that means that the player wants to save the game
				if (nChoose == 1)
				{
					SaveFile(arrnGameBoard);
				}

				//Stopping the game
				break;
			}

			// Check if the cell is taken
			while (arrnGameBoard[nRow][nCol] != EMPTY)
			{
				cout << " The cell is already in taken " << endl;
				cin >> nRow >> nCol;
			}

			arrnGameBoard[nRow][nCol] = WHITE;
			cout << arrnGameBoard[nRow][nCol] << endl;
			g_WhiteCells++;

			//Check if a bridge have been created
			if (IsBridge(arrnGameBoard, nRow, nCol, WHITE))
			{
				cout << " !!! Bridge !!!" << endl;
			}

			PrintMatrix(arrnGameBoard);
		}
		break;
	}
	default:
	{

		break;
		}
	}
	// If the matrix is full so the game ends.
	if (IsFullMat(arrnGameBoard))
	{
		// If there were more white cells
		if (g_WhiteCells > g_BlackCells)
		{
			cout << "The player with the white cells is the winner !";
		}

		// If there were more black cells
		if (g_WhiteCells < g_BlackCells)
		{
			cout << "The player with the black cells is the winner !";
		}

		// If the amount is same so there is a draw
		if (g_WhiteCells == g_BlackCells)
		{
			cout << "Draw ! you both are the winners !";
		}
	}
}