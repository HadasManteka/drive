#define _CRT_SECURE_NO_WARNINGS
#include <iostream>	
#include <string>
#include <fstream>
using namespace std;

// Const definition
const char WALL_VALUE	   = '+';
const int WALL_SIZE		   = 1;
const int MAT_SIZE_ROW 	   = 30;
const int MAT_SIZE_COL	   = 30;
const int WORDS_IN_FILE    = 30;
const int WORD_MAX_LENGTH  = 15;
const int VEC_SIZE		   = 2;
const int GO_EAST		   = 1;
const int GO_SOUTH		   = 2;
const int WIDTH			   = 1;
const int HEIGHT		   = 2;
const char WORDS_FILE_NAME[] = "WORD_FILE_NAME.txt";
const char OUTPUT_FILE_NAME[] = "Output.txt";

// Globals defintion
int g_Search = 1;
int g_WordsSum = 0;

// Struct definition 
struct Word
{
	int nValue;
	char arrcWord[WORD_MAX_LENGTH];
	bool bIsUsed = false;
};

//-----------------------------------------------------------------------------------
//								    		Check Space Func
//									     ----------------------
//
// General		: Checks if there enough space for a certian word in the matrix
//
// Parameters	:
//		 iarrcMat - The matrix (In).
//		 inRow    - The row of the incommon letter between wrdWord and 
//				    the word that in the matrix (In).
//		 inCol    - The row of the incommon letter between wrdWord and 
//			        the word that in the matrix (In).
//		 iwrdWord - The word that need to be placed (In).
//	
// Return Value : The direction to place the word.
//				  If there word is not fit so it returns 0.
//
//-----------------------------------------------------------------------------------
int CheckSpace(char(&iarrcMAT)[MAT_SIZE_ROW + 2 * WALL_SIZE][MAT_SIZE_COL + 2 * WALL_SIZE], int inRow, int inCol, Word iwrdWord)
{

	// Variables declaration
	char* cPointer = strchr(iwrdWord.arrcWord, iarrcMAT[inRow][inCol]);
	int  nWordAfterLength;
	int  nWordBeforeLength;
	bool bIsSouth = false;
	bool bIsEast = false;
	int  nRowIndex;
	int  nColIndex;

	// Code section

	// Calculating the length of the word after and before the incommon letter
	nWordAfterLength = strlen(cPointer) - 1;
	nWordBeforeLength = strlen(iwrdWord.arrcWord) - nWordAfterLength - 1;

	// Cheking if there is enough space for placing the word toward south
	for (nRowIndex = inRow + 1; nRowIndex <= inRow + nWordAfterLength; nRowIndex++)
	{

		// Checking if the next cells are empty
		if (iarrcMAT[nRowIndex][inCol] == '-')
		{
			bIsSouth = true;
		}
		else
		{
			bIsSouth = false;
			break;
		}
	}

	// Check if south is clear
	if (bIsSouth)
	{

		// Cheking if there is enough space for placing the word toward north
		for (nRowIndex = inRow - 1; nRowIndex >= inRow - nWordBeforeLength; nRowIndex--)
		{

			// Checking if the next cells are empty
			if (iarrcMAT[nRowIndex][inCol] == '-')
			{
				bIsSouth = true;
			}
			else
			{
				bIsSouth = false;

				break;
			}
		}
	}

	// If bIsSouth is false so that means that we need to check for the east side
	if (bIsSouth)
	{

		return (GO_SOUTH);
	}

	// Cheking if there is enough space for placing the word toward east
	for (nColIndex = inCol + 1; nColIndex <= inCol + nWordAfterLength; nColIndex++)
	{

		// Checking if the next cells are empty
		if (iarrcMAT[inRow][nColIndex] == '-')
		{
			bIsEast = true;
		}
		else
		{
			bIsEast = false;

			break;
		}
	}

	// Check if east is clear
	if (bIsEast)
	{

		// Cheking if there is enough space for placing the word toward west
		for (nColIndex = inCol - 1; nColIndex >= inCol - nWordAfterLength; nColIndex--)
		{

			// Checking if the next cells are empty
			if (iarrcMAT[inRow][nColIndex] == '-')
			{
				bIsEast = true;
			}
			else
			{
				bIsEast = false;

				break;
			}
		}
	}

	// If bIsEast is false so that means that there is no space for this word
	if (bIsEast)
	{
		return (GO_EAST);
	}

	// Means that the word is not fit
	return (0);
}

//---------------------------------------------------------------------------------
//							 Scan Words Func
//							----------------
//
// General		 : Scanning the matrix for searching incommon
//				   letters with the words that are in the matrix and the words
//				   that are in wrdWords array
//
//
// Parameters	 :
//		iarrcMat  - the matrix (In).
//		iarrwrdWords - Words array (In).
//		inRow  	  - The row of the letter in the matrix(In).
//		inCol	  - The col of the letter in the matrix (In).
//
// Return Value	 : None.
//
//----------------------------------------------------------------------------------
void ScanWords(char(&iarrcMAT)[MAT_SIZE_ROW + 2 * WALL_SIZE][MAT_SIZE_COL + 2 * WALL_SIZE], Word iarrwrdWords[], int inRow, int inCol)
{
	struct Point
	{
		int nX;
		int nY;
	};

	// Variables definition
	int  nRowStrike;
	int  nColStrike;
	int  nDirectionIndex;
	int  nIndex;
	int  nColIndex;
	int  nRowIndex;
	char *cPointerSource;
	int  nPlaceDirection;
	char cLetter = ' ';

	// Arrays definition
	Point arrpntVec_arr[VEC_SIZE];

	arrpntVec_arr[0].nX = 0;
	arrpntVec_arr[0].nY = 1;


	arrpntVec_arr[1].nX = 1;
	arrpntVec_arr[1].nY = 0;

	// Check the type of search
	if (g_Search == WIDTH)
	{
		cLetter = iarrcMAT[inRow][inCol + 1];
	}

	// Check the type of search
	if (g_Search == HEIGHT)
	{
		cLetter = iarrcMAT[inRow + 1][inCol];
	}

	for (nIndex = 0; nIndex < WORDS_IN_FILE; nIndex++)
	{
		// Get pointer to the incommon letter
		cPointerSource = strchr(iarrwrdWords[nIndex].arrcWord, cLetter);

		// Checking that the word is not placed yet
		if (cPointerSource && !iarrwrdWords[nIndex].bIsUsed)
		{
			//Checking if there is enough place for the word
			if (g_Search == WIDTH)
			{
				nPlaceDirection = CheckSpace(iarrcMAT, inRow, inCol + 1, iarrwrdWords[nIndex]);
			}
			if (g_Search == HEIGHT)
			{
				nPlaceDirection = CheckSpace(iarrcMAT, inRow + 1, inCol, iarrwrdWords[nIndex]);
			}
			// Calculating the length of the word after and before the incommon letter
			int nWordAfterLength = strlen(cPointerSource) - 1;
			int nWordBeforeLength = strlen(iarrwrdWords[nIndex].arrcWord) - nWordAfterLength - 1;

			// Checking placing direction
			switch (nPlaceDirection)
			{
			case (GO_EAST):
			{

				// Adding word's value
				g_WordsSum += iarrwrdWords[nIndex].nValue;

				// Getting ahead from the incommon letter
				cPointerSource++;
				for (nColIndex = inCol + 1; nColIndex <= inCol + nWordAfterLength; nColIndex++)
				{
					iarrcMAT[inRow + arrpntVec_arr[0].nY][nColIndex + arrpntVec_arr[0].nX] = *cPointerSource;
					cPointerSource++;
				}
				cPointerSource = strchr(iarrwrdWords[nIndex].arrcWord, cLetter);

				//Getting  back form the incommon letter
				cPointerSource--;
				for (nColIndex = inCol - 1; nColIndex > inCol - nWordBeforeLength; nColIndex--)
				{
					iarrcMAT[inRow + arrpntVec_arr[0].nY][nColIndex + arrpntVec_arr[0].nX] = *cPointerSource;
					cPointerSource--;
				}

				break;
			}

			case (GO_SOUTH):
			{

				// Adding word's value
				g_WordsSum += iarrwrdWords[nIndex].nValue;

				// Getting ahead from the incommon letter
				cPointerSource++;
				for (nRowIndex = inRow + 1; nRowIndex <= inRow + nWordAfterLength; nRowIndex++)
				{
					iarrcMAT[nRowIndex + arrpntVec_arr[1].nY][inCol + arrpntVec_arr[1].nX] = *cPointerSource;
					cPointerSource++;
				}
				cPointerSource = strchr(iarrwrdWords[nIndex].arrcWord, cLetter);

				// Getting back from the incommon letter
				cPointerSource--;
				for (nRowIndex = inRow - 1; nRowIndex > inRow - nWordBeforeLength; nRowIndex--)
				{
					iarrcMAT[nRowIndex + arrpntVec_arr[1].nY][inCol + arrpntVec_arr[1].nX] = *cPointerSource;
					cPointerSource--;
				}
			}
			default:
			{

				break;
			}
		}

			// Mark the word as one that already been used
			iarrwrdWords[nIndex].bIsUsed = true;
			return;
		}
	}
}

//---------------------------------------------------------------------------------
//								Scan Mat Func
//							   --------------
//
// General		 : Scanning the matrix and looking for letters.
//				   If a letter found the function calls to ScanWord function.
//
//
// Parameters	 :
//		iarrcMat	 - the matrix (In).
//		iarrwrdWords - Words array (In).
//
// Return Value	 : None.
//
//----------------------------------------------------------------------------------
void ScanMat(char(&iarrcMAT)[MAT_SIZE_ROW + 2 * WALL_SIZE][MAT_SIZE_COL + 2 * WALL_SIZE], Word iarrwrdWords[])
{

	// Variables definition
	int nRowIndex;
	int nColIndex;

	// Code section

	// Scanning the matrix
	for (nRowIndex = 1; nRowIndex <= MAT_SIZE_ROW; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_SIZE_COL; nColIndex++)
		{

			// Checking if there as a letter in the matrix
			if (iarrcMAT[nRowIndex][nColIndex] != '-')
			{
				ScanWords(iarrcMAT, iarrwrdWords, nRowIndex, nColIndex);
			}
		}
	}
}

//---------------------------------------------------------------------------------
//								Save Into File Func
//							   ---------------------
//
// General		 : Writing the matrix 'iarrcMat' into a file 
//				   and also writing the sum of the value of all 
//				   the words that placed in the matrix 
//
//
// Parameters	 :
//		iarrcMat - the matrix (In).
//
// Return Value	 : None.
//
//----------------------------------------------------------------------------------
void SaveIntoFile(char(&iarrcMAT)[MAT_SIZE_ROW + 2 * WALL_SIZE][MAT_SIZE_COL + 2 * WALL_SIZE])
{

	// File definition
	fstream fsFilePointer;

	// Variables definition
	int nRow;
	int nCol;

	// Code section

	// Opening file for writing
	fsFilePointer.open(OUTPUT_FILE_NAME, ios::out);

	// Scanning the matrix
	for (nRow = 1; nRow <= MAT_SIZE_ROW; nRow++)
	{
		for (nCol = 1; nCol <= MAT_SIZE_COL; nCol++)
		{

			// Writing the matrix content
			fsFilePointer << iarrcMAT[nRow][nCol];
		}

		fsFilePointer << endl;
	}

	// Writing to the file the sum of the words's value
	fsFilePointer << endl << g_WordsSum << endl;
}

//-----------------------------------------------------------------------------
//						   	 Scrabble
//							-----------
//
// General : The program simulate the game scrabble.
//
// Input : Words and thier values from a text file
//
// Process : Placing the words from the file in the matrix 
//			 according to the 'Scrabble' rules.
//
// Output : Prints the matrix into a file.
//
//-----------------------------------------------------------------------------
// Programmer : Itay Knurovich
// Student No : 8699636
// Date		  : 15.05.2019
//-----------------------------------------------------------------------------
void main()
{

	// Variables definition
	int  nRowIndex;
	int  nColIndex;
	int  nLoopIndex;
	int  nWordsIndex = 0;
	int	 nValueBuffer;
	char szWordBuffer[WORD_MAX_LENGTH];

	// Arrays definition
	char arrcGameBoard[MAT_SIZE_ROW + 2 * WALL_SIZE][MAT_SIZE_COL + 2 * WALL_SIZE];
	Word arrwrdWords[WORDS_IN_FILE];

	// File definition
	fstream fsFilePointer;

	//Code section

	//Setting up the security wall
	for (nRowIndex = 0; nRowIndex < MAT_SIZE_ROW + 2 * WALL_SIZE; nRowIndex++)
	{
		for (nColIndex = 0; nColIndex < MAT_SIZE_COL + 2 * WALL_SIZE; nColIndex++)
		{
			arrcGameBoard[nRowIndex][nColIndex] = WALL_VALUE;
		}
	}

	//Setting up the inner matrix
	for (nRowIndex = 1; nRowIndex <= MAT_SIZE_ROW; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_SIZE_COL; nColIndex++)
		{
			arrcGameBoard[nRowIndex][nColIndex] = '-';
		}
	}

	// Opening the file
	fsFilePointer.open(WORDS_FILE_NAME, ios::in);

	// Checking if the file didnt open
	if (!fsFilePointer.is_open())
	{
		cout << "ERROR OPENING FILE" << endl;
		exit;
	}

	// Reading from the file
	while (!fsFilePointer.eof())
	{

		// Writing to the arrwrdWords array the words information from the file
		fsFilePointer >> nValueBuffer;
		arrwrdWords[nWordsIndex].nValue = nValueBuffer;
		fsFilePointer.getline(arrwrdWords[nWordsIndex].arrcWord, WORD_MAX_LENGTH);
		arrwrdWords[nWordsIndex].bIsUsed = false;

		// Increasing words array index
		nWordsIndex++;
	}

	// We read all the file's records, now we can close it
	fsFilePointer.close();

	// The first word that in arrwrdWords is the one
	// with the heighest value.
	// Placing it in the middle of the gameboard
	int nMidBoardRow = (MAT_SIZE_ROW) / 2 - 1;
	int nMidBoardCol = (MAT_SIZE_COL) / 2 - 1;
	int nWordIndex = 1;
	while (arrwrdWords[0].arrcWord[nWordIndex] != '\0')
	{
		arrcGameBoard[nMidBoardRow][nMidBoardCol] = arrwrdWords[0].arrcWord[nWordIndex];
		nMidBoardCol++;
		nWordIndex++;
	}

	// Adding to the g_WordsSum the value of the first word that already placed
	g_WordsSum += arrwrdWords[0].nValue;
	arrwrdWords[0].bIsUsed = true;

	// Scanning the matrix as times as the max words in file.
	// Im doing 2 searchs beacuse the first is for width
	// and the second for height.
	for (int nLoopIndex = 0; nLoopIndex < WORDS_IN_FILE; nLoopIndex++)
	{
		g_Search = WIDTH;
		ScanMat(arrcGameBoard, arrwrdWords);
		g_Search = HEIGHT;
		ScanMat(arrcGameBoard, arrwrdWords);
	}

	// Writing into the file the output
	SaveIntoFile(arrcGameBoard);
}
