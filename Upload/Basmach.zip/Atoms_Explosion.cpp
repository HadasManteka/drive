#include <iostream>
#include <string>
#include <fstream>
#define _CRT_SECURE_NO_WARNINGS
using namespace std;

// Const declaration
const int MAT_ROW_SIZE = 600;
const int MAT_COL_SIZE = 500;
const int VEC_SIZE	   = 4;
const int WALL_SIZE    = 1;
const char FILE_NAME[] = "Atoms.bat";

// Globals definition
int g_Poped = 0;

// Enum declaration
enum Cell
{
	WALL,
	EMPTY,
	ATOM,
	NEUTRON_UP,
	NEUTRON_DOWN,
	NEUTRON_LEFT,
	NEUTRON_RIGHT,
	EXPLOSION
};

// Global Structs declaration
struct Point
{

	//Row
	int nY;

	//Col
	int nX;
};

//-----------------------------------------------------------------------------
//							 Is Neutron Func
//							 ----------------
//
// General : Check if a certian cell in a matrix is a neutron.
//
//
// Parameters :
//		iarrcllMatrix - The matrix (In).
//		inRow		  - Row of certian cell (In).
//		inCol         - Col of certian cell (In).
//
// Return Value : True  - if the cell is a neutron,
//				  False - if not.
//
//-----------------------------------------------------------------------------
bool IsNeutron(Cell(&iarrcllMatrix)[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE], int inRow, int inCol)
{
	
	// Check if this cell is a neutron
	if (iarrcllMatrix[inRow][inCol] == NEUTRON_UP ||
		iarrcllMatrix[inRow][inCol] == NEUTRON_DOWN ||
		iarrcllMatrix[inRow][inCol] == NEUTRON_RIGHT ||
		iarrcllMatrix[inRow][inCol] == NEUTRON_LEFT)
	{

		return (true);
	}
	else
	{

		return (false);
	}
}

//-----------------------------------------------------------------------------
//							  Print Matrix Func
//							 -------------------
//
// General : Prints a matrix.
//
//
// Parameters :
//		iarrcllMatrix - The matrix to print (In).
//	
// Return Value : None.
//
//-----------------------------------------------------------------------------
void PrintMatrix(Cell(&iarrcllMatrix)[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE])
{

	// Code section

	for (int i = 1; i <= MAT_ROW_SIZE; i++)
	{
		for (int j = 1; j <= MAT_COL_SIZE; j++)
		{
			
			// To know what color to print
			switch (iarrcllMatrix[i][j])
			{
				case (ATOM):
				{
					cout << " | A";

					break;
				}
				case (EXPLOSION):
				{
					cout << " | E";

					break;
				}
				case (EMPTY):
				{ 
					cout << " |  ";

					break;
				}
				default:
				{

					break;
				}
			}

			// Check if neutron to print 'N'
			if (IsNeutron(iarrcllMatrix, i, j))
			{
				cout << " | N";
			}
		}

		cout << endl;
	}

	cout << endl << endl;
}

//-----------------------------------------------------------------------------
//							     Scan Mat Func
//							    ---------------
//
// General : Scan the matrix , if it locate a neutron that came into an atom it is popping him.
//			 If it locate a neutron it moves him to his specific way.
//			 If it locate 2 neutron that crash into each other , they disappear.
//			 
//
// Parameters :
//		iarrcllMatrix - The matrix (In/Out).
//	
// Return Value : None.
//
//-----------------------------------------------------------------------------
void ScanMat(Cell(&ioarrcllMatrix)[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE])
{

	// Variables declaration
	int nIndex;
	int nYCordinate;
	int nColIndex;
	int nRowIndex;

	// Arrays declaration
	Point arrpntDirectionsArray[VEC_SIZE];

	// Code section

	// Insert direction array it values
	arrpntDirectionsArray[0] = { -1,0 };
	arrpntDirectionsArray[1] = { 1,0 };
	arrpntDirectionsArray[2] = { 0,1 };
	arrpntDirectionsArray[3] = { 0,-1 };

	// Scanning thw whole matrix
	for (nRowIndex = 1; nRowIndex <= MAT_ROW_SIZE; nRowIndex++)
	{
		for (nColIndex = 1; nColIndex <= MAT_COL_SIZE; nColIndex++)
		{
			// Checking matrix cells
			switch (ioarrcllMatrix[nRowIndex][nColIndex])
			{
				case (NEUTRON_UP):
				{

					// If the neutron moves into an atom	
					if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] == ATOM)
				{
					ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] = EXPLOSION;
				}

					// If the next cell is neutron they are cancel each other
					else if (IsNeutron(ioarrcllMatrix, nRowIndex + arrpntDirectionsArray[0].nY, nColIndex + arrpntDirectionsArray[0].nX))
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] = EMPTY;
					}

					// If the neutron moves into a wall it cancels him
					else if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] == WALL)
					{
						ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
					}
					else
					{

						// If we are here so that means that the next cell is clear and we can to move to him.
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] = NEUTRON_UP;
					}
					ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
	
					break;
				}
				case (NEUTRON_DOWN):
				{

					// If the neutron moves into an atom
					if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] == ATOM)
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] = EXPLOSION;
					}

					// If the next cell is neutron they are cancel each other
					else if (IsNeutron(ioarrcllMatrix, nRowIndex + arrpntDirectionsArray[1].nY, nColIndex + arrpntDirectionsArray[1].nX))
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] = EMPTY;
					}


					// If the neutron moves into a wall it cancels him
					else if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] == WALL)
					{
						ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
					}
					else
					{

						// If we are here so that means that the next cell is clear and we can to move to him.
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] = NEUTRON_DOWN;
					}

					ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;

					break;
				}
				case (NEUTRON_RIGHT):
				{

					// If the neutron moves into an atom
					if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] == ATOM)
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] = EXPLOSION;
					}

					// If the next cell is neutron they are cancel each other
					else if (IsNeutron(ioarrcllMatrix, nRowIndex + arrpntDirectionsArray[2].nY, nColIndex + arrpntDirectionsArray[2].nX))
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] = EMPTY;
					}

					// If the neutron moves into a wall it cancels him
					else if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] == WALL)
					{
						ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
					}
					else
					{

						// If we are here so that means that the next cell is clear and we can to move to him.
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] = NEUTRON_RIGHT;
					}

					ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
						
					break;
				}
				case (NEUTRON_LEFT):
				{

					// If the neutron moves into an atom
					if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] == ATOM)
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] = EXPLOSION;
					}

					// If the next cell is neutron they are cancel each other
					else if (IsNeutron(ioarrcllMatrix, nRowIndex + arrpntDirectionsArray[3].nY, nColIndex + arrpntDirectionsArray[3].nX))
					{
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] = EMPTY;
					}

					// If the neutron moves into a wall it cancels him
					else if (ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] == WALL)
					{
						ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;
					}
					else
					{

						// If we are here so that means that the next cell is clear and we can to move to him.
						ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] = NEUTRON_LEFT;
					}
					ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;

					break;
				}

				// Explosion state means that in this turn the atom is split to 4 new neutrons
				case (EXPLOSION):
				{ 
				
					// Increase the amount of poped atoms
					g_Poped++;
					ioarrcllMatrix[nRowIndex][nColIndex] = EMPTY;

					// Split the atom for 4 neutrons
					ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[0].nY][nColIndex + arrpntDirectionsArray[0].nX] = NEUTRON_UP;
					ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[1].nY][nColIndex + arrpntDirectionsArray[1].nX] = NEUTRON_DOWN;
					ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[2].nY][nColIndex + arrpntDirectionsArray[2].nX] = NEUTRON_RIGHT;
					ioarrcllMatrix[nRowIndex + arrpntDirectionsArray[3].nY][nColIndex + arrpntDirectionsArray[3].nX] = NEUTRON_LEFT;

					// Print the matrix
					PrintMatrix(ioarrcllMatrix);

					break;
				}
				default:
				{

					break;
				}
			}
		}
	}
}

//-----------------------------------------------------------------------------
//						  Atomic Explosion
//						--------------------
//
// General : The program simulate the process atomic explosion
//
// Input : Atoms locations from a binary file
//
// Process : Popping one atom and by that calculate how many
//			 atoms have been popped by that first pop.
//
// Output : The matrix and  Prints how many atoms have been popped.
//
//-----------------------------------------------------------------------------
// Programmer : Itay Knurovich
// Student No : 8699636 
// Date : 15.05.2019
//-----------------------------------------------------------------------------
void main()
{

	// Variabels definition
	int	nAmountOfAtoms;
	int	nXCordinate;
	int	nYCordinate;
	int	nAtomsIndex = 0;
	int	nIndex	    = 0;
	int	nRow		= 0;
	int nCol		= 0;
	int nRowIndex;
	int nLoopIndex;
	int nColIndex;

	// File definition
	fstream fsFilePointer;

	// Arrays definition
	Point arrpntDirectionsArray[VEC_SIZE];
	Cell arrcllAtomsMatrix[MAT_ROW_SIZE + 2 * WALL_SIZE][MAT_COL_SIZE + 2 * WALL_SIZE];

	// Code section
	
	// Security wall
	for (nRowIndex = 0; nRowIndex < MAT_ROW_SIZE + 2 * WALL_SIZE; nRowIndex++)
	{
		for (nColIndex = 0; nColIndex < MAT_COL_SIZE + 2 * WALL_SIZE; nColIndex++)
		{
			arrcllAtomsMatrix[nRowIndex][nColIndex] = WALL;
		}
	}

	// Put empty values in the matrix
	// except the security wall
	for (nRow = 1;
		nRow <= MAT_ROW_SIZE;
		nRow++)
	{
		for (nCol = 1;
			nCol < MAT_COL_SIZE;
			nCol++)
		{
			arrcllAtomsMatrix[nRow][nCol] = EMPTY;
		}
	}

	// Opening binary file for reading
	fsFilePointer.open(FILE_NAME, ios::binary | ios::in);

	// Reads the atmos amount 
	fsFilePointer >> nAmountOfAtoms;

	while (!fsFilePointer.eof())
	{

		// Reads the atoms locations;
		fsFilePointer >> nYCordinate;
		fsFilePointer >> nXCordinate;

		// Insert the atoms to the matrix
		// Cordinate + 1 beacuse the file starts from 0 and in row and col 0
		// Is the security wall
		arrcllAtomsMatrix[nYCordinate][nXCordinate] = ATOM;
	}

	// We've reached to the end of the file
	// so now we can close it
	fsFilePointer.close();

	// Directions array initiallize
	arrpntDirectionsArray[0] = { -1,0 };
	arrpntDirectionsArray[1] = { 1,0 };
	arrpntDirectionsArray[2] = { 0,1 };
	arrpntDirectionsArray[3] = { 0,-1 };

	// I chose for start popping the last atom that came into the matrix
	arrcllAtomsMatrix[nYCordinate][nXCordinate] = EMPTY;

	// Splitting the atom to 4 new neutrons
	arrcllAtomsMatrix[nYCordinate + arrpntDirectionsArray[0].nY][nXCordinate + arrpntDirectionsArray[0].nX] = NEUTRON_UP;
	arrcllAtomsMatrix[nYCordinate + arrpntDirectionsArray[1].nY][nXCordinate + arrpntDirectionsArray[1].nX] = NEUTRON_DOWN;
	arrcllAtomsMatrix[nYCordinate + arrpntDirectionsArray[2].nY][nXCordinate + arrpntDirectionsArray[2].nX] = NEUTRON_RIGHT;
	arrcllAtomsMatrix[nYCordinate + arrpntDirectionsArray[3].nY][nXCordinate + arrpntDirectionsArray[3].nX] = NEUTRON_LEFT;

	// Increase the global variable because we poped the last atom
	g_Poped++;

	// Print the matrix
	PrintMatrix(arrcllAtomsMatrix);

	// Scan the matrix cells for all it's width
	for ( nLoopIndex = 0; nLoopIndex < MAT_COL_SIZE; nLoopIndex++)
	{
		ScanMat(arrcllAtomsMatrix);
	}

	// Giving output of how mant atoms have been popped.
	cout << " Atoms that have been popped : " << g_Poped << endl;
}